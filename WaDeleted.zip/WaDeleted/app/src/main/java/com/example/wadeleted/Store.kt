package com.example.wadeleted

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val sender: String, val text: String, val time: Long, val deleted: Boolean)

object Store {
    private const val KEY = "msgs"
    private const val MAX = 1000
    private val markers = listOf("this message was deleted", "pesan ini telah dihapus", "you deleted this message")

    private fun sp(c: Context) = c.getSharedPreferences("wa", Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): MutableList<Msg> {
        val arr = JSONArray(sp(c).getString(KEY, "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Msg(o.getString("s"), o.getString("t"), o.getLong("ts"), o.getBoolean("d"))
        }
    }

    private fun save(c: Context, list: List<Msg>) {
        val arr = JSONArray()
        list.takeLast(MAX).forEach {
            arr.put(JSONObject().put("s", it.sender).put("t", it.text).put("ts", it.time).put("d", it.deleted))
        }
        sp(c).edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized
    fun add(c: Context, sender: String, text: String) {
        val list = all(c)
        val isDeleteNotice = markers.any { text.contains(it, ignoreCase = true) }
        if (isDeleteNotice) {
            // Tandai pesan terakhir dari pengirim ini sebagai dihapus
            val i = list.indexOfLast { it.sender == sender && !it.deleted }
            if (i >= 0) list[i] = list[i].copy(deleted = true)
        } else {
            val now = System.currentTimeMillis()
            val last = list.lastOrNull { it.sender == sender }
            if (last != null && last.text == text && now - last.time < 3000) return
            list.add(Msg(sender, text, now, false))
        }
        save(c, list)
    }

    fun clear(c: Context) = sp(c).edit().remove(KEY).apply()
}
