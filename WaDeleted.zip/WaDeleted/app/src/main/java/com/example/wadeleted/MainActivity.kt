package com.example.wadeleted

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var list: ListView
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 16) }
        status = TextView(this).apply { textSize = 14f }
        val open = Button(this).apply {
            text = "Buka Akses Notifikasi"
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        val clear = Button(this).apply {
            text = "Hapus Riwayat"
            setOnClickListener { Store.clear(this@MainActivity); refresh() }
        }
        list = ListView(this)
        root.addView(status); root.addView(open); root.addView(clear)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun enabled(): Boolean =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(ComponentName(this, WaListener::class.java).flattenToString()) == true

    private fun refresh() {
        status.text = if (enabled()) "Akses notifikasi: AKTIF" else "Akses notifikasi: BELUM AKTIF (tekan tombol di bawah)"
        val rows = Store.all(this).reversed().map {
            val t = DateFormat.format("dd/MM HH:mm", it.time)
            (if (it.deleted) "🗑 DIHAPUS · " else "") + "${it.sender} · $t\n${it.text}"
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
    }
}
